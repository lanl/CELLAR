#ifdef MPI_CPP_USE_STUB
#include "mpi_stub.h"
#else
#include <mpi.h>
#endif